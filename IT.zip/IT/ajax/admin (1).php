<?php
session_start();
include 'connect.php';
$query="select id,can_name from voting";
$result=mysqli_query($db,$query) or die("error querying database");

echo "<table border='1' align='center'>
<tr>
<th>STUDENT ID-NO</th>
<th>STUDENT NAME</th>
<th></th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['can_name'] . "</td>";
echo "<td> <form action='upload.php'
method='post' enctype='multipart/form-data'>
<input type='file' name='file_name' id='fileupload'/>
<input type='submit' value='submit'/></td>";
echo "</tr>";
}
echo "</table>";
?>
