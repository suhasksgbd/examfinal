<?php
$db=mysqli_connect('localhost','root','tiger','2015cse150') or die("error connecting to database".mysqli_error($db));
?>
