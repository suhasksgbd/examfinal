
var NAME_PATTERN = new RegExp("[A-Za-z]+");

function validateForm() {
    var firstname = document.forms.signin_form.firstname.value;
    var lastname = document.forms.signin_form.lastname.value;
    if (firstname == "" || !NAME_PATTERN.test(firstname)) {
        alert("First name is invalid");
        return false;
    }
    if (lastname == "" || !NAME_PATTERN.test(lastname)) {
        alert("Last name is invalid");
        return false;
    }
    
    if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.signin_form.email.value)) {
        alert("Email is invalid");
        return false;
    }
    
    if (!/^[0-9]+([.][0-9]+)?$/.test(document.signin_form.cgpa.value)) {
        alert("invalid cgpa");
        return false;
    }
    if (document.signin_form.password.value != document.signin_form.confirmpassword.value) {
        alert("Enter same passwords!");
        return false;
    }
    return true;
}